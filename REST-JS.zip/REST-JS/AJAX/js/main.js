//create the object of XML HTTP Request
var xhr = new XMLHttpRequest();
xhr.open('GET','http://localhost:9090/RestUserManagement/rest/users',true);
xhr.responseType='text';
xhr.send();

xhr.onload= function(){
    if(xhr.status==200){
        var data=JSON.parse(xhr.responseText);
        myString="<table>";
        myString+="<tr>";
        myString+="<th>Username</th>";
        myString+="<th>Firstname</th>";
        myString+="<th>Lastname</th>";
        myString+="<th>MobileNumber</th>";
        myString+="</tr>";

       for(var i=0;i<data.length;i++)
       {
           myString+="<tr>";
           myString+="<td>"+data[i].username+"</td>";
           myString+="<td>"+data[i].firstname+"</td>";
           myString+="<td>"+data[i].lastname+"</td>";
           myString+="<td>"+data[i].mobilenumber+"</td>";
           myString+="</tr>";
       } 
       myString+="</table>";

        document.getElementById("container").innerHTML=myString;
    }

}